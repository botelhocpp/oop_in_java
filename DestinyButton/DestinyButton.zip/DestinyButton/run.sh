#!/bin/bash
java -jar bin/DestinyButton.jar